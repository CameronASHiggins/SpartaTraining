package org.example.D;

public interface Worker {
    public void doesJob();

    public String getName();

}
